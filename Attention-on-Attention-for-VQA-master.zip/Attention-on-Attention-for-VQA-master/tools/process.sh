# Process data

python tools/create_dictionary.py
python tools/compute_softscore.py
python tools/detection_features_converter.py
python tools/test_detection_features_converter.py
